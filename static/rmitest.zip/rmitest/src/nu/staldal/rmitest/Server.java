package nu.staldal.rmitest;

import java.io.*;
import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.rmi.registry.Registry;
import java.rmi.registry.LocateRegistry;


public class Server 
{
    private Server() {}
    
    public static void main(String args[])
        throws RemoteException, AlreadyBoundException, IOException
    {	
        int port = Integer.parseInt(args[0]);
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

        System.err.println("Start");
        br.readLine();        
        
        MyRemoteInterface obj = new MyRemoteImpl();
        MyRemoteInterface stub = 
            (MyRemoteInterface)UnicastRemoteObject.exportObject(obj, port);
        System.err.println("Object exported");
        br.readLine();
                    
        // Bind the remote object's stub in the registry
        Registry registry = LocateRegistry.createRegistry(port);
        registry.bind("Foo", stub);       
        System.err.println("Object bound");

        System.err.println("Server ready");
        br.readLine();
        System.err.println("Server exiting");
    }
    
}

