package nu.staldal.rmitest;

import java.rmi.*;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Client 
{
    private Client() {}

    public static void main(String[] args)
        throws RemoteException, NotBoundException
    {
        String host = args[0];
        int port = Integer.parseInt(args[1]);
        Registry registry = LocateRegistry.getRegistry(host, port);
        MyRemoteInterface stub = (MyRemoteInterface)registry.lookup("Foo");
        
        System.out.println("parseInt(77) = " + stub.parseInt("77"));
        try {
            System.out.println("parseInt(foo) = " + stub.parseInt("foo"));
        }
        catch (NumberFormatException e)
        {
            System.out.println("parseInt(foo) threw " + e.toString());                
        }
        
        try {
            System.out.println("getHostAddress() = " + stub.getHostAddress());
        }
        catch (java.net.UnknownHostException e)
        {
            System.out.println("getHostAddress() threw " + e.toString());                
        }
    }
}

