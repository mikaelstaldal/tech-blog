package nu.staldal.rmitest;
	
import java.net.InetAddress;
import java.net.UnknownHostException;	


public class MyRemoteImpl implements MyRemoteInterface
{
	
    public MyRemoteImpl() {}


    public int parseInt(String s) 
        throws NumberFormatException
    {
        return Integer.parseInt(s);
    }
            
    
    public InetAddress getHostAddress() 
        throws UnknownHostException
    {
        return InetAddress.getLocalHost();        
    }

}

