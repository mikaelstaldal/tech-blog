package nu.staldal.rmitest;

import java.rmi.Remote;
import java.rmi.RemoteException;

import java.net.InetAddress;
import java.net.UnknownHostException;


public interface MyRemoteInterface extends Remote 
{
    
    /**
     * Parse a String into an integer.
     *
     * @param s  the string to be parsed
     *
     * @return the parsed integer
     *
     * @throws NumberFormatException if the parsing fails
     */
    public int parseInt(String s) 
        throws RemoteException, NumberFormatException;
    
    
    /**
     * Get the IP address of the remote machine.
     *
     * @return the IP address
     *
     * @throws UnknownHostException if no IP address for the host could be found.
     */     
    public InetAddress getHostAddress() 
        throws RemoteException, UnknownHostException;
        
}

